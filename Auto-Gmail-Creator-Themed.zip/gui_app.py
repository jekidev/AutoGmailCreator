import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import threading
import subprocess
import sys
import os
import random
import time

# Try to import the original script's functions
try:
    import auto_gmail_creator as agc
except ImportError:
    pass

class GmailCreatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Auto-Gmail-Creator - NordicSec Edition")
        self.root.geometry("800x600")
        self.root.resizable(False, False)
        
        self.setup_background()
        self.setup_ui()
        
    def setup_background(self):
        # Load and set background image
        bg_path = os.path.join(os.path.dirname(__file__), "background.png")
        if os.path.exists(bg_path):
            self.bg_image = Image.open(bg_path)
            self.bg_image = self.bg_image.resize((800, 600), Image.Resampling.LANCZOS)
            self.bg_photo = ImageTk.PhotoImage(self.bg_image)
            
            self.bg_label = tk.Label(self.root, image=self.bg_photo)
            self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)
        else:
            self.root.configure(bg="#1a1a1a")

    def setup_ui(self):
        # Overlay frame with transparency effect (using a dark background)
        self.overlay = tk.Frame(self.root, bg="#000000", bd=0)
        self.overlay.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=600, height=500)
        
        # Main Content inside overlay
        content = tk.Frame(self.overlay, bg="#000000", padx=20, pady=20)
        content.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = tk.Label(content, text="AUTO-GMAIL-CREATOR", fg="#00ff00", bg="#000000", font=("Courier", 20, "bold"))
        title_label.pack(pady=10)
        
        subtitle_label = tk.Label(content, text="NordicSec Authorized Tool", fg="#00ff00", bg="#000000", font=("Courier", 10))
        subtitle_label.pack(pady=5)

        # Settings Frame
        settings_frame = tk.LabelFrame(content, text=" CONFIGURATION ", fg="#00ff00", bg="#000000", font=("Courier", 10, "bold"), padx=10, pady=10)
        settings_frame.pack(fill=tk.X, pady=10)
        
        # Number of accounts
        tk.Label(settings_frame, text="ACCOUNTS TO CREATE:", fg="#00ff00", bg="#000000", font=("Courier", 10)).grid(row=0, column=0, sticky=tk.W, pady=5)
        self.num_accounts = tk.IntVar(value=5)
        tk.Entry(settings_frame, textvariable=self.num_accounts, width=10, bg="#1a1a1a", fg="#00ff00", insertbackground="#00ff00", bd=1).grid(row=0, column=1, sticky=tk.W, pady=5, padx=10)
        
        # Password
        tk.Label(settings_frame, text="DEFAULT PASSWORD:", fg="#00ff00", bg="#000000", font=("Courier", 10)).grid(row=1, column=0, sticky=tk.W, pady=5)
        self.password = tk.StringVar(value="ShadowHacker##$$%%^^&&")
        tk.Entry(settings_frame, textvariable=self.password, width=30, bg="#1a1a1a", fg="#00ff00", insertbackground="#00ff00", bd=1).grid(row=1, column=1, sticky=tk.W, pady=5, padx=10)
        
        # Log Area
        log_frame = tk.LabelFrame(content, text=" SYSTEM LOG ", fg="#00ff00", bg="#000000", font=("Courier", 10, "bold"), padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.log_text = tk.Text(log_frame, height=10, bg="#000000", fg="#00ff00", font=("Courier", 9), state=tk.DISABLED, bd=0)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbar for log
        scrollbar = tk.Scrollbar(self.log_text)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.log_text.yview)
        
        # Buttons
        btn_frame = tk.Frame(content, bg="#000000")
        btn_frame.pack(fill=tk.X, pady=10)
        
        self.start_btn = tk.Button(btn_frame, text="[ START OPERATION ]", command=self.start_creation, bg="#1a1a1a", fg="#00ff00", font=("Courier", 10, "bold"), activebackground="#00ff00", activeforeground="#000000", bd=1)
        self.start_btn.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)
        
        self.stop_btn = tk.Button(btn_frame, text="[ ABORT ]", command=self.stop_creation, state=tk.DISABLED, bg="#1a1a1a", fg="#ff0000", font=("Courier", 10, "bold"), activebackground="#ff0000", activeforeground="#000000", bd=1)
        self.stop_btn.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)
        
        self.running = False

    def log(self, message):
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"> {time.strftime('%H:%M:%S')} | {message}\n")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)

    def start_creation(self):
        if self.running:
            return
        
        self.running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        
        threading.Thread(target=self.creation_loop, daemon=True).start()

    def stop_creation(self):
        self.running = False
        self.log("ABORT SIGNAL RECEIVED. CLEANING UP...")
        self.stop_btn.config(state=tk.DISABLED)

    def creation_loop(self):
        try:
            import auto_gmail_creator as agc
            agc.your_password = self.password.get()
            
            count = self.num_accounts.get()
            self.log(f"INITIALIZING OPERATION: {count} ACCOUNTS")
            
            for i in range(count):
                if not self.running:
                    break
                
                self.log(f"EXECUTING TASK {i+1}/{count}...")
                try:
                    # Execute the creation logic
                    agc.create_multiple_accounts(1)
                    self.log(f"TASK {i+1} SUCCESSFUL")
                except Exception as e:
                    self.log(f"TASK {i+1} FAILED: {str(e)}")
                
                if i < count - 1 and self.running:
                    wait_time = random.randint(5, 10)
                    self.log(f"COOLDOWN: {wait_time}s")
                    time.sleep(wait_time)
                
            self.log("OPERATION COMPLETE.")
        except Exception as e:
            self.log(f"CRITICAL SYSTEM ERROR: {str(e)}")
        finally:
            self.running = False
            self.root.after(0, lambda: self.start_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_btn.config(state=tk.DISABLED))

if __name__ == "__main__":
    root = tk.Tk()
    app = GmailCreatorGUI(root)
    root.mainloop()
